package exe20221026;

public class StampaVariabili {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int intero=9;
		float reale=1.44f;
		boolean boleano=true;
		System.out.println("numero intero "+intero );
		System.out.println("numero reale " +reale );
		System.out.println("numero boleano "+boleano );

	}

}
